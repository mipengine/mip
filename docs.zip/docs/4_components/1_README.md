# 组件概述

MIP组件有两种：基础组件和个性化组件。

- 内置组件

    - 图片组件（mip-img）
    - 视频组件（mip-video）
    - mip-pix组件（mip-pix）


- 扩展通用组件

    - 轮播组件（mip-carousel）
    - iframe组件（mip-iframe）
    - 广告组件（mip-ad）


- 个性化组件
	
    - 推荐组件（mip-recommend）
    - 分享组件（mip-share）
    - app下载组件（mip-appdl）
    - 百度统计组件（mip-baidu-stats）
    - 个性化广告组件 （mip-ad-customize）
